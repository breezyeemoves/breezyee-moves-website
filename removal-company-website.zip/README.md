# BreeZyee Moves Website

This is the official website for BreeZyee Moves, a professional removal company serving London and surrounding area's.

## Getting Started

### Prerequisites

- Node.js 18.x or later
- npm or yarn

### Installation

1. Clone the repository
\`\`\`bash
git clone https://github.com/yourusername/breezyee-moves.git
cd breezyee-moves
\`\`\`

2. Install dependencies
\`\`\`bash
npm install
# or
yarn install
\`\`\`

3. Set up environment variables
Create a `.env.local` file in the root directory with the following variables:
\`\`\`
NEXT_PUBLIC_APP_URL=http://localhost:3000
RESEND_API_KEY=your_resend_api_key
DATABASE_URL=your_database_url
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
\`\`\`

4. Run the development server
\`\`\`bash
npm run dev
# or
yarn dev
\`\`\`

5. Open [http://localhost:3000](http://localhost:3000) in your browser to see the result.

## Deployment

### Deploying to Vercel

1. Push your code to a GitHub repository
2. Import the project in Vercel
3. Set up the environment variables in the Vercel dashboard
4. Deploy

### Manual Deployment

1. Build the project
\`\`\`bash
npm run build
# or
yarn build
\`\`\`

2. Start the production server
\`\`\`bash
npm start
# or
yarn start
\`\`\`

## Project Structure

- `app/` - Next.js App Router pages and layouts
- `components/` - React components
- `lib/` - Utility functions and helpers
- `public/` - Static assets
- `utils/` - Utility functions specific to certain features

## Technologies Used

- Next.js 14
- React 18
- TypeScript
- Tailwind CSS
- Supabase
- Resend (for emails)
- shadcn/ui components

## License

This project is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.

## Contact

For any inquiries, please contact us at contactus@breezyeemoves.co.uk
\`\`\`

Let's create a simple privacy policy page:
