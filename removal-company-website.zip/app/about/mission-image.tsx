import Image from "next/image"

export default function MissionImage() {
  return (
    <div className="relative rounded-lg overflow-hidden">
      <Image
        src="/breezyee-team.jpeg"
        alt="BreeZyee Moves Team"
        width={800}
        height={600}
        className="object-cover w-full h-auto"
      />
    </div>
  )
}
