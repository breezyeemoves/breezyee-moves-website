import { CheckCircle2, Award, Users, Clock, Heart, MapPin } from "lucide-react"
import Image from "next/image"
import Teamwork from "@/components/teamwork"

export const metadata = {
  title: "About Us | BreeZyee Moves",
  description:
    "Learn about BreeZyee Moves, our mission to empower NEET young people, and the team behind our professional removal services.",
}

export default function AboutPage() {
  const values = [
    {
      icon: Award,
      title: "Excellence",
      description:
        "We strive for excellence in every move, paying attention to the smallest details to ensure a perfect service.",
    },
    {
      icon: Users,
      title: "Customer Focus",
      description:
        "Our customers are at the heart of everything we do. We listen, adapt, and deliver services tailored to your needs.",
    },
    {
      icon: Clock,
      title: "Reliability",
      description:
        "We understand the importance of timing in moves. You can count on us to be punctual and deliver as promised.",
    },
    {
      icon: Heart,
      title: "Social Impact",
      description:
        "We're committed to making a positive difference in our community by empowering young people to build brighter futures.",
    },
  ]

  return (
    <div>
      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">About Us</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Learn about our company, our mission, and the team behind our professional removal services.
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  BreeZyee Moves was founded with a simple mission: to take the stress out of moving while making a
                  positive impact in our community. What started as a small business has grown into one of the most
                  trusted removal companies in London and surrounding areas.
                </p>
                <p>
                  Our slogan, "A Day's Move in a Breeze!" reflects our commitment to making your moving experience as
                  smooth and effortless as possible.
                </p>
                <p>
                  At BreeZyee Moves, we bridge gaps for young people not in education, employment, or training (NEET),
                  empowering them to overcome challenges and build brighter futures. Every move you book with us helps
                  support this important mission.
                </p>
              </div>

              <div className="mt-8">
                <h3 className="text-xl font-semibold mb-4">Why Choose Us?</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Professional and reliable removal services</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Fully trained and professional moving staff</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Comprehensive insurance coverage for peace of mind</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Modern fleet of vehicles and equipment</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Social impact through youth employment and training</span>
                  </li>
                  <li className="flex items-start">
                    <MapPin className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span className="uppercase">LONDON & SURROUNDING AREA'S</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="relative flex items-center justify-center">
              <div className="relative w-[300px] h-[450px] md:w-[350px] md:h-[500px] rounded-lg overflow-hidden shadow-lg border-4 border-breezyee-teal/20">
                <Image src="/breezyee-team.jpeg" alt="BreeZyee Moves Team" fill className="object-cover" priority />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Add the Teamwork component here */}
      <Teamwork />

      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              At BreeZyee Moves, we bridge gaps for young people (NEET), empowering them to overcome challenges and
              build brighter futures.
            </p>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-sm max-w-3xl mx-auto">
            <div className="flex flex-col md:flex-row gap-6 items-center">
              <div className="md:w-1/3">
                <div className="rounded-lg overflow-hidden">
                  <div className="relative" style={{ width: "300px", height: "400px", overflow: "hidden" }}>
                    <Image
                      src="/breezyee-team-loading.jpeg"
                      alt="BreeZyee team members loading a moving van"
                      fill
                      className="object-cover object-center"
                      style={{ objectPosition: "center 40%" }}
                    />
                  </div>
                </div>
              </div>
              <div className="md:w-2/3">
                <h3 className="text-xl font-semibold mb-3">Social Impact</h3>
                <p className="mb-4">
                  We believe that a move for you is a leap for the next generation. By choosing BreeZyee Moves, you're
                  not just getting exceptional moving services – you're helping us create opportunities for young people
                  who need them most.
                </p>
                <p>
                  Through training, employment, and mentorship, we help young people develop skills, gain confidence,
                  and build careers in the moving industry and beyond.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Values</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              These core values guide everything we do at BreeZyee Moves.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-background p-6 rounded-lg shadow-sm">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                  <value.icon className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                <p className="text-muted-foreground">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-6">Join Us in Making a Difference</h2>
          <p className="text-lg text-primary-foreground/90 max-w-3xl mx-auto mb-8">
            By choosing BreeZyee Moves, you're not just getting exceptional moving services – you're helping us create
            opportunities for young people in our community.
          </p>
        </div>
      </section>
    </div>
  )
}
