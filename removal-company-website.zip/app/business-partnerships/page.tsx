import {
  Building,
  CheckCircle2,
  Handshake,
  Home,
  Package,
  TruckIcon,
  Boxes,
  BarChart,
  Calendar,
  ClipboardList,
} from "lucide-react"
import Image from "next/image"
import BusinessPartnershipForm from "@/components/business-partnership-form"

export const metadata = {
  title: "Business Partnerships | BreeZyee Moves",
  description:
    "Partner with BreeZyee Moves for your logistics and removal needs. We offer tailored solutions for estate agents, property managers, and businesses.",
}

export default function BusinessPartnershipsPage() {
  const benefits = [
    "Dedicated account manager for all your moving needs",
    "Priority booking for your clients",
    "Customized service packages to suit your business requirements",
    "Competitive rates with partnership discounts",
    "Regular service quality reviews",
    "Co-branded marketing materials available",
    "Professional and reliable service reflecting positively on your business",
    "Support our social mission to help NEET young people",
  ]

  const partnerTypes = [
    {
      title: "Estate Agents",
      description: "Offer your clients a seamless moving experience with our professional removal services.",
      icon: Home,
    },
    {
      title: "Property Managers",
      description: "Streamline tenant moves and property maintenance with our reliable services.",
      icon: Building,
    },
    {
      title: "Corporate Relocations",
      description: "Support your employees with professional moving services during corporate relocations.",
      icon: Handshake,
    },
  ]

  const smallBusinessServices = [
    {
      title: "Regular Delivery Services",
      description: "Scheduled delivery routes for your products or materials to customers or between locations.",
      icon: TruckIcon,
    },
    {
      title: "Inventory Transportation",
      description: "Moving stock between warehouses, stores, or distribution centres with careful handling.",
      icon: Boxes,
    },
    {
      title: "Equipment Relocation",
      description: "Safe transportation of business equipment, machinery, or office furniture.",
      icon: Package,
    },
    {
      title: "Seasonal Storage Solutions",
      description: "Secure storage for seasonal inventory, documents, or equipment when not in use.",
      icon: BarChart,
    },
    {
      title: "On-Demand Logistics Support",
      description: "Flexible logistics assistance for unexpected needs or during peak business periods.",
      icon: Calendar,
    },
    {
      title: "Supply Chain Management",
      description: "Comprehensive logistics planning and execution to optimise your supply chain operations.",
      icon: ClipboardList,
    },
  ]

  return (
    <div>
      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Business Partnerships</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Partner with BreeZyee Moves for all your logistics and removal needs. We offer tailored solutions for
              estate agents, property managers, and businesses.
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Why Partner With Us?</h2>
              <p className="text-muted-foreground mb-6">
                At BreeZyee Moves, we understand the importance of reliable logistics partners for your business. Our
                professional removal services can complement your offerings and provide added value to your clients.
              </p>

              <ul className="space-y-2 mb-6">
                {benefits.map((benefit, i) => (
                  <li key={i} className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="relative h-80 md:h-[400px] rounded-lg overflow-hidden shadow-lg">
              <Image
                src="/business-partnership-handshake.jpeg"
                alt="Business partnership handshake"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Who We Partner With</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We work with various businesses to provide seamless moving experiences.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {partnerTypes.map((type, index) => (
              <div key={index} className="bg-background p-6 rounded-lg shadow-sm">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                  <type.icon className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-breezyee-purple">{type.title}</h3>
                <p className="text-muted-foreground">{type.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Small Business Logistics Solutions</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We offer specialized logistics services to help small businesses streamline their operations and focus on
              growth.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {smallBusinessServices.map((service, index) => (
              <div
                key={index}
                className="bg-background p-6 rounded-lg shadow-sm border border-breezyee-teal/10 hover:border-breezyee-teal/30 transition-colors"
              >
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                  <service.icon className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-breezyee-purple">{service.title}</h3>
                <p className="text-muted-foreground">{service.description}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 p-6 bg-muted rounded-lg max-w-3xl mx-auto">
            <h3 className="text-xl font-semibold mb-4 text-center">How Our Small Business Logistics Works</h3>
            <ol className="space-y-4">
              <li className="flex items-start">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary mr-3">
                  <span className="font-medium">1</span>
                </div>
                <div>
                  <p className="font-medium">Initial Consultation</p>
                  <p className="text-muted-foreground">
                    We meet to understand your specific logistics needs and challenges.
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary mr-3">
                  <span className="font-medium">2</span>
                </div>
                <div>
                  <p className="font-medium">Customized Solution</p>
                  <p className="text-muted-foreground">
                    We design a tailored logistics plan that fits your business operations and budget.
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary mr-3">
                  <span className="font-medium">3</span>
                </div>
                <div>
                  <p className="font-medium">Implementation</p>
                  <p className="text-muted-foreground">Our team integrates seamlessly with your business processes.</p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary mr-3">
                  <span className="font-medium">4</span>
                </div>
                <div>
                  <p className="font-medium">Ongoing Support</p>
                  <p className="text-muted-foreground">
                    Regular reviews and adjustments to ensure optimal performance.
                  </p>
                </div>
              </li>
            </ol>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Partner With Us</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Fill out the form below to inquire about our business partnership opportunities. Our team will contact you
              to discuss how we can work together.
            </p>
          </div>

          <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-lg shadow-sm">
            <BusinessPartnershipForm />
          </div>
        </div>
      </section>
    </div>
  )
}
