import { Loader2 } from "lucide-react"

export default function Loading() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh]">
      <Loader2 className="h-16 w-16 text-breezyee-teal animate-spin mb-4" />
      <h2 className="text-xl font-medium text-muted-foreground">Loading...</h2>
    </div>
  )
}
