import ContactForm from "@/components/contact-form"
import { MapPin, Phone, Mail, Clock, Globe } from "lucide-react"

export const metadata = {
  title: "Contact Us | BreeZyee Moves",
  description:
    "Get in touch with BreeZyee Moves for a free quote or to discuss your moving needs. We're here to help make your move stress-free.",
}

export default function ContactPage() {
  const contactInfo = [
    {
      icon: MapPin,
      title: "Service Area",
      details: "LONDON & SURROUNDING AREAS",
    },
    {
      icon: Phone,
      title: "Phone",
      details: [
        { number: "020 3633 0464", link: "tel:02036330464" },
        { number: "07398 395 022", link: "tel:07398395022" },
      ],
      isMultiple: true,
    },
    {
      icon: Mail,
      title: "Email",
      details: "contactus@breezyeemoves.co.uk",
      link: "mailto:contactus@breezyeemoves.co.uk",
    },
    {
      icon: Globe,
      title: "Website",
      details: "www.breezyeemoves.co.uk",
      link: "https://www.breezyeemoves.co.uk",
    },
    {
      icon: Clock,
      title: "Business Hours",
      details: "24/7 Mon-Friday, Sat: 8am-8pm",
    },
  ]

  return (
    <div>
      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Contact Us</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Get in touch with our team for a free quote or to discuss your moving needs.
            </p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold mb-6">Send Us a Message</h2>
              <ContactForm />
            </div>

            <div>
              <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
              <div className="space-y-6">
                {contactInfo.map((item, index) => (
                  <div key={index} className="flex">
                    <div className="mr-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <item.icon className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium">{item.title}</h3>
                      {item.isMultiple ? (
                        <div className="space-y-1">
                          {item.details.map((detail, i) => (
                            <a key={i} href={detail.link} className="block text-muted-foreground hover:text-primary">
                              {detail.number}
                            </a>
                          ))}
                        </div>
                      ) : item.link ? (
                        <a href={item.link} className="text-muted-foreground hover:text-primary">
                          {item.details}
                        </a>
                      ) : (
                        <p className="text-muted-foreground">{item.details}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 p-6 bg-muted rounded-lg">
                <h3 className="font-medium mb-2">Need a quick response?</h3>
                <p className="text-muted-foreground mb-4">
                  Call us directly for immediate assistance with your moving needs.
                </p>
                <div className="space-y-2">
                  <a
                    href="tel:02036330464"
                    className="block inline-flex items-center text-primary hover:text-primary/80 font-medium"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    020 3633 0464
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
