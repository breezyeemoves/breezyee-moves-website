import type { MetadataRoute } from "next"

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "BreeZyee Moves - Professional Removal Services",
    short_name: "BreeZyee Moves",
    description:
      "Professional removal services, man and van hire, and self-drive van hire in London and surrounding areas.",
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#20B2AA",
    icons: [
      {
        src: "/favicon.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: "/favicon.png",
        sizes: "512x512",
        type: "image/png",
      },
    ],
  }
}
