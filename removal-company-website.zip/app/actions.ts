"use server"

import { createClient } from "@/utils/supabase/server"
import { Resend } from "resend"
import { format } from "date-fns"

type ContactFormData = {
  name: string
  email: string
  phone: string
  moveType: string
  message: string
}

export async function submitContactForm(formData: ContactFormData) {
  const supabase = createClient()

  // Insert the contact form data into Supabase
  const { data, error } = await supabase
    .from("contact_submissions")
    .insert([
      {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        move_type: formData.moveType,
        message: formData.message,
        status: "new",
      },
    ])
    .select()

  if (error) {
    console.error("Error submitting contact form:", error)
    throw new Error("Failed to submit contact form")
  }

  // Send notification email
  try {
    if (process.env.RESEND_API_KEY) {
      const resend = new Resend(process.env.RESEND_API_KEY)

      const serviceTypeMap: Record<string, string> = {
        "home-removals": "Home Removal",
        "office-relocations": "Office Relocation",
        packing: "Packing Service",
        "van-hire": "Van Hire",
        storage: "Storage Solution",
        "hire-a-breezer": "Hire a Breezer",
        other: "Other Service",
      }

      const serviceTypeDisplay = serviceTypeMap[formData.moveType] || formData.moveType

      await resend.emails.send({
        from: "BreeZyee Moves <onboarding@resend.dev>",
        to: "contactus@breezyeemoves.co.uk",
        subject: `New Contact Form Submission: ${serviceTypeDisplay}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #20B2AA;">New Contact Form Submission</h1>
            <p><strong>Name:</strong> ${formData.name}</p>
            <p><strong>Email:</strong> ${formData.email}</p>
            <p><strong>Phone:</strong> ${formData.phone}</p>
            <p><strong>Service Type:</strong> ${serviceTypeDisplay}</p>
            <p><strong>Message:</strong> ${formData.message}</p>
            <hr style="border-top: 1px solid #eee; margin: 20px 0;" />
            <p style="color: #666; font-size: 14px;">This is an automated email from your website.</p>
          </div>
        `,
      })
    }
  } catch (emailError) {
    console.error("Error sending notification email:", emailError)
    // We don't throw here as the form submission was successful
  }

  return { success: true }
}

type VanBookingData = {
  name: string
  email: string
  phone: string
  vanSize: string
  pickupDate: Date
  pickupTime: string
  duration: string
  additionalInfo: string
}

export async function submitVanBooking(formData: VanBookingData) {
  const supabase = createClient()

  // Insert the van booking data into Supabase
  const { data, error } = await supabase
    .from("van_bookings")
    .insert([
      {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        van_size: formData.vanSize,
        pickup_date: formData.pickupDate.toISOString(),
        pickup_time: formData.pickupTime,
        duration: formData.duration,
        additional_info: formData.additionalInfo,
        status: "pending",
      },
    ])
    .select()

  if (error) {
    console.error("Error submitting van booking:", error)
    throw new Error("Failed to submit van booking")
  }

  // Send notification email
  try {
    if (process.env.RESEND_API_KEY) {
      const resend = new Resend(process.env.RESEND_API_KEY)

      const vanSizeMap: Record<string, string> = {
        small: "Small Van",
        medium: "Medium Van",
        large: "Large Van",
      }

      const durationMap: Record<string, string> = {
        "half-day": "Half Day (4 hours)",
        "full-day": "Full Day (8 hours)",
        "multiple-days": "Multiple Days",
      }

      const formattedDate = format(formData.pickupDate, "PPP")
      const vanSizeDisplay = vanSizeMap[formData.vanSize] || formData.vanSize
      const durationDisplay = durationMap[formData.duration] || formData.duration

      await resend.emails.send({
        from: "onboarding@resend.dev",
        to: "contactus@breezyeemoves.co.uk", // Updated email address
        subject: `New Van Booking Request: ${vanSizeDisplay}`,
        html: `
          <h1>New Van Booking Request</h1>
          <p><strong>Name:</strong> ${formData.name}</p>
          <p><strong>Email:</strong> ${formData.email}</p>
          <p><strong>Phone:</strong> ${formData.phone}</p>
          <p><strong>Van Size:</strong> ${vanSizeDisplay}</p>
          <p><strong>Pickup Date:</strong> ${formattedDate}</p>
          <p><strong>Pickup Time:</strong> ${formData.pickupTime}</p>
          <p><strong>Duration:</strong> ${durationDisplay}</p>
          <p><strong>Additional Info:</strong> ${formData.additionalInfo}</p>
        `,
      })
    }
  } catch (emailError) {
    console.error("Error sending notification email:", emailError)
    // We don't throw here as the form submission was successful
  }

  return { success: true }
}

type RemovalBookingData = {
  name: string
  email: string
  phone: string
  moveType: string
  propertySize: string
  moveDate: Date
  moveTime: string
  fromAddress: string
  toAddress: string
  additionalInfo: string
}

export async function submitRemovalBooking(formData: RemovalBookingData) {
  const supabase = createClient()

  // Insert the removal booking data into Supabase
  const { data, error } = await supabase
    .from("removal_bookings")
    .insert([
      {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        move_type: formData.moveType,
        property_size: formData.propertySize,
        move_date: formData.moveDate.toISOString(),
        move_time: formData.moveTime,
        from_address: formData.fromAddress,
        to_address: formData.toAddress,
        additional_info: formData.additionalInfo,
        status: "pending",
      },
    ])
    .select()

  if (error) {
    console.error("Error submitting removal booking:", error)
    throw new Error("Failed to submit removal booking")
  }

  // Send notification email
  try {
    if (process.env.RESEND_API_KEY) {
      const resend = new Resend(process.env.RESEND_API_KEY)

      const moveTypeMap: Record<string, string> = {
        "home-removals": "Home Removal",
        "office-relocations": "Office Relocation",
        packing: "Packing Service",
        storage: "Storage Solution",
        other: "Other Service",
      }

      const formattedDate = format(formData.moveDate, "PPP")
      const moveTypeDisplay = moveTypeMap[formData.moveType] || formData.moveType

      await resend.emails.send({
        from: "BreeZyee Moves <onboarding@resend.dev>",
        to: "contactus@breezyeemoves.co.uk",
        subject: `New Removal Booking Request: ${moveTypeDisplay}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #20B2AA;">New Removal Booking Request</h1>
            <p><strong>Name:</strong> ${formData.name}</p>
            <p><strong>Email:</strong> ${formData.email}</p>
            <p><strong>Phone:</strong> ${formData.phone}</p>
            <p><strong>Service Type:</strong> ${moveTypeDisplay}</p>
            <p><strong>Property Size:</strong> ${formData.propertySize}</p>
            <p><strong>Move Date:</strong> ${formattedDate}</p>
            <p><strong>Move Time:</strong> ${formData.moveTime}</p>
            <p><strong>From Address:</strong> ${formData.fromAddress}</p>
            <p><strong>To Address:</strong> ${formData.toAddress}</p>
            <p><strong>Additional Info:</strong> ${formData.additionalInfo}</p>
            <hr style="border-top: 1px solid #eee; margin: 20px 0;" />
            <p style="color: #666; font-size: 14px;">This is an automated email from your website.</p>
          </div>
        `,
      })
    }
  } catch (emailError) {
    console.error("Error sending notification email:", emailError)
    // We don't throw here as the form submission was successful
  }

  return { success: true }
}
