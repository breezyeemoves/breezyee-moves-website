import Link from "next/link"

export const metadata = {
  title: "Terms of Service | BreeZyee Moves",
  description: "Terms of Service for BreeZyee Moves - Learn about our terms and conditions for using our services.",
}

export default function TermsOfServicePage() {
  return (
    <div className="container py-12 md:py-16">
      <div className="max-w-4xl mx-auto prose prose-lg">
        <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>

        <p>
          Last updated: {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
        </p>

        <h2>1. Introduction</h2>
        <p>
          These terms and conditions govern your use of the BreeZyee Moves website and services. By using our website or
          services, you accept these terms and conditions in full. If you disagree with these terms and conditions or
          any part of them, you must not use our website or services.
        </p>

        <h2>2. Services</h2>
        <p>
          BreeZyee Moves provides removal services, man and van hire, and self-drive van hire in London and surrounding
          area's. The specific details, terms, and conditions of each service will be provided at the time of booking.
        </p>

        <h2>3. Booking and Cancellation</h2>
        <p>
          When you book our services, you are entering into a contract with us. Cancellations made more than 7 days
          before your scheduled service are fully refundable. For cancellations within 7 days, a cancellation fee may
          apply. Please contact us as soon as possible if you need to cancel or reschedule.
        </p>

        <h2>4. Payment</h2>
        <p>
          Payment terms will be specified at the time of booking. We accept various payment methods including
          credit/debit cards and bank transfers. Full payment or a deposit may be required to confirm your booking.
        </p>

        <h2>5. Insurance and Liability</h2>
        <p>
          We have comprehensive insurance coverage for our services. However, we recommend that you ensure your
          belongings are adequately insured during the move. Our liability is limited to the terms specified in our
          insurance policy.
        </p>

        <h2>6. Website Use</h2>
        <p>
          You must not use our website in any way that causes, or may cause, damage to the website or impairment of the
          availability or accessibility of the website, or in any way which is unlawful, illegal, fraudulent or harmful.
        </p>

        <h2>7. Intellectual Property</h2>
        <p>
          All content on our website, including text, graphics, logos, images, and software, is the property of BreeZyee
          Moves or our content suppliers and is protected by UK and international copyright laws.
        </p>

        <h2>8. Changes to Terms</h2>
        <p>
          We may revise these terms and conditions at any time by amending this page. You are expected to check this
          page from time to time to take notice of any changes we made, as they are binding on you.
        </p>

        <h2>9. Contact Us</h2>
        <p>If you have any questions about these terms and conditions, please contact us at:</p>
        <p>
          Email: contactus@breezyeemoves.co.uk
          <br />
          Phone: 020 3633 0464
        </p>

        <div className="mt-8">
          <Link href="/" className="text-breezyee-teal hover:underline">
            Return to Home Page
          </Link>
        </div>
      </div>
    </div>
  )
}
