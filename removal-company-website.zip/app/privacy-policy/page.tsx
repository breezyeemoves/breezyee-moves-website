import Link from "next/link"

export const metadata = {
  title: "Privacy Policy | BreeZyee Moves",
  description: "Privacy Policy for BreeZyee Moves - Learn how we collect, use, and protect your personal information.",
}

export default function PrivacyPolicyPage() {
  return (
    <div className="container py-12 md:py-16">
      <div className="max-w-4xl mx-auto prose prose-lg">
        <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>

        <p>
          Last updated: {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
        </p>

        <h2>1. Introduction</h2>
        <p>
          Welcome to BreeZyee Moves. We respect your privacy and are committed to protecting your personal data. This
          privacy policy will inform you about how we look after your personal data when you visit our website and tell
          you about your privacy rights and how the law protects you.
        </p>

        <h2>2. The Data We Collect About You</h2>
        <p>
          Personal data, or personal information, means any information about an individual from which that person can
          be identified. We may collect, use, store and transfer different kinds of personal data about you which we
          have grouped together as follows:
        </p>
        <ul>
          <li>Identity Data: includes first name, last name, username or similar identifier.</li>
          <li>Contact Data: includes billing address, delivery address, email address and telephone numbers.</li>
          <li>
            Technical Data: includes internet protocol (IP) address, browser type and version, time zone setting and
            location, browser plug-in types and versions, operating system and platform, and other technology on the
            devices you use to access this website.
          </li>
          <li>Usage Data: includes information about how you use our website, products and services.</li>
        </ul>

        <h2>3. How We Use Your Personal Data</h2>
        <p>
          We will only use your personal data when the law allows us to. Most commonly, we will use your personal data
          in the following circumstances:
        </p>
        <ul>
          <li>Where we need to perform the contract we are about to enter into or have entered into with you.</li>
          <li>
            Where it is necessary for our legitimate interests (or those of a third party) and your interests and
            fundamental rights do not override those interests.
          </li>
          <li>Where we need to comply with a legal obligation.</li>
        </ul>

        <h2>4. Data Security</h2>
        <p>
          We have put in place appropriate security measures to prevent your personal data from being accidentally lost,
          used or accessed in an unauthorized way, altered or disclosed. In addition, we limit access to your personal
          data to those employees, agents, contractors and other third parties who have a business need to know.
        </p>

        <h2>5. Data Retention</h2>
        <p>
          We will only retain your personal data for as long as reasonably necessary to fulfill the purposes we
          collected it for, including for the purposes of satisfying any legal, regulatory, tax, accounting or reporting
          requirements.
        </p>

        <h2>6. Your Legal Rights</h2>
        <p>
          Under certain circumstances, you have rights under data protection laws in relation to your personal data,
          including the right to request access, correction, erasure, restriction, transfer, to object to processing, to
          portability of data and (where the lawful ground of processing is consent) to withdraw consent.
        </p>

        <h2>7. Contact Us</h2>
        <p>If you have any questions about this privacy policy or our privacy practices, please contact us at:</p>
        <p>
          Email: contactus@breezyeemoves.co.uk
          <br />
          Phone: 020 3633 0464
        </p>

        <div className="mt-8">
          <Link href="/" className="text-breezyee-teal hover:underline">
            Return to Home Page
          </Link>
        </div>
      </div>
    </div>
  )
}
