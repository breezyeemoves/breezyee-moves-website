import { Truck, CheckCircle2, CalendarRange } from "lucide-react"
import Image from "next/image"
import VanBookingForm from "@/components/van-booking-form"

export const metadata = {
  title: "Van Hire | BreeZyee Moves",
  description:
    "Book a van for your DIY move. We offer a range of van sizes from small to large to suit your needs, with flexible rental periods and competitive pricing.",
}

export default function VanHirePage() {
  const features = [
    "Various van sizes available - small (Citroen Berlingo), medium, large, and Luton",
    "All vehicles have automatic transmission for easy driving",
    "Flexible rental periods - half day, full day, or multiple days",
    "Competitive pricing with no hidden fees",
    "Well-maintained, clean vehicles",
    "Optional moving equipment rental",
    "Comprehensive insurance coverage",
    "24/7 breakdown assistance",
  ]

  return (
    <div>
      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Van Hire</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Need a van for your DIY move? We offer a range of vans for hire, from small vans for single items to large
              Luton vans for full house moves.
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                <Truck className="h-6 w-6" />
              </div>
              <h2 className="text-3xl font-bold mb-6">Our Van Hire Service</h2>
              <p className="text-muted-foreground mb-6">
                Whether you're moving a few items or an entire home, our van hire service provides you with the perfect
                vehicle for your needs. All our vans feature automatic transmission for easy driving, are regularly
                serviced, clean, and come with comprehensive insurance for your peace of mind.
              </p>

              <ul className="space-y-2 mb-6">
                {features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-8 p-6 bg-muted rounded-lg">
                <h3 className="text-xl font-semibold mb-4">Small Van Specifications (Citroen Berlingo)</h3>
                <p className="mb-4">
                  Our small vans (Citroen Berlingo) are perfect for moving smaller items, studio flats, or when you need
                  a compact, fuel-efficient option.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Load space: Up to 400 cubic feet</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Payload capacity: Up to 650kg</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Automatic transmission for easy driving</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Perfect for small moves and single items</span>
                  </li>
                </ul>

                <h3 className="text-xl font-semibold mb-4 mt-8">Medium Van Specifications</h3>
                <p className="mb-4">
                  Our medium vans (Citroen Dispatch or similar) are perfect for moving the contents of a 1-2 bedroom
                  flat or multiple large items.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Load space: Up to 650 cubic feet</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Payload capacity: Up to 1,000kg</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Automatic transmission for easy driving</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Bluetooth connectivity and modern features</span>
                  </li>
                </ul>

                <h3 className="text-xl font-semibold mb-4 mt-8">Large Van Specifications (Mercedes-Benz Sprinter)</h3>
                <p className="mb-4">
                  Our large vans (Mercedes-Benz Sprinter) are ideal for moving larger homes or office spaces, offering
                  ample space and reliability.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Load space: Up to 1000 cubic feet</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Payload capacity: Up to 1,100kg</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Automatic transmission for easy driving</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Perfect for 2-3 bedroom house moves or office relocations</span>
                  </li>
                </ul>

                <h3 className="text-xl font-semibold mb-4 mt-8">Luton Van Specifications</h3>
                <p className="mb-4">
                  Our Luton vans (Mercedes-Benz Sprinter or similar) are ideal for larger moves, offering maximum space
                  and reliability.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Load space: Up to 1400 cubic feet</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Payload capacity: Up to 1,200kg</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Automatic transmission for easy driving</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>Perfect for 3+ bedroom house moves</span>
                  </li>
                </ul>
              </div>

              <div className="flex items-center p-4 bg-muted rounded-lg mb-6">
                <CalendarRange className="h-6 w-6 text-primary mr-3" />
                <p className="text-sm">
                  <span className="font-medium">Booking Notice:</span> Please book at least 24 hours in advance to
                  ensure availability. For same-day bookings, please call us directly.
                </p>
              </div>
            </div>

            <div className="relative h-80 md:h-[500px] w-full">
              <div className="rounded-lg overflow-hidden shadow-lg border-4 border-breezyee-teal/20">
                <Image
                  src="/luton-van-hire.jpeg"
                  alt="Mercedes-Benz Luton van available for hire"
                  fill
                  className="object-cover object-center"
                  sizes="(max-width: 768px) 100vw, 50vw"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Book a Van</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Fill out the form below to book a van. We'll confirm availability and provide you with all the details you
              need.
            </p>
          </div>

          <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-lg shadow-sm">
            <VanBookingForm />
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Book Your Van?</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8">
            Fill out the form above to book your van. We'll confirm availability and provide you with all the details
            you need.
          </p>
        </div>
      </section>
    </div>
  )
}
