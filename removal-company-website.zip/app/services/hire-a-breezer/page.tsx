import { Button } from "@/components/ui/button"
import { HelpingHand, CheckCircle2, Clock, Calendar, PenToolIcon as Tool, MapPin, Briefcase } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import BreezerBookingForm from "@/components/breezer-booking-form"

export const metadata = {
  title: "Hire a Breezer | BreeZyee Moves London",
  description:
    "Hire our young, energetic Breezers for everyday tasks in London. From moving furniture to garden work, our Breezers are ready to help with any task you need assistance with.",
  keywords:
    "hire help london, moving assistance, furniture assembly, garden work, home organisation, loading help, event setup, breezer hire",
}

export default function HireABreezerPage() {
  const tasks = [
    "Moving furniture within your home",
    "Garden work and landscaping",
    "Home organisation and decluttering",
    "Painting and decorating assistance",
    "Furniture assembly",
    "Loading and unloading vehicles",
    "Clearing out garages or lofts",
    "Helping with house or office moves",
    "Event setup and breakdown",
    "General labor and heavy lifting",
  ]

  const breezerServices = [
    {
      icon: Tool,
      title: "Home Tasks",
      description: "Furniture assembly, moving items, home organisation, and general assistance around the house.",
    },
    {
      icon: Briefcase,
      title: "Office Support",
      description: "Office moves, furniture rearrangement, equipment setup, and general office tasks.",
    },
    {
      icon: Calendar,
      title: "Event Assistance",
      description: "Setup and breakdown for events, moving equipment, and general event support.",
    },
    {
      icon: MapPin,
      title: "Outdoor Work",
      description: "Garden maintenance, yard cleanup, and outdoor organisation tasks.",
    },
  ]

  return (
    <div>
      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Hire a Breezer</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Need an extra pair of hands? Our young, energetic 'Breezers' are ready to help with a wide range of
              everyday tasks.
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                <HelpingHand className="h-6 w-6" />
              </div>
              <h2 className="text-3xl font-bold mb-6">How It Works</h2>
              <p className="text-muted-foreground mb-6">
                Our 'Hire a Breezer' service connects you with our trained young employees who can help with a variety
                of tasks. Whether you need help moving furniture, organising your home, or tackling garden work, our
                Breezers are ready to assist.
              </p>

              <div className="space-y-6 mb-6">
                <div className="flex items-start">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary mr-3">
                    <span className="font-medium">1</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Choose How Many Breezers You Need</h3>
                    <p className="text-muted-foreground">
                      Select from 1 to 20 Breezers depending on the size and complexity of your task.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary mr-3">
                    <span className="font-medium">2</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Select Your Preferred Date and Time</h3>
                    <p className="text-muted-foreground">
                      Book your Breezers for a time that works for you - hourly, half-day, or full-day.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary mr-3">
                    <span className="font-medium">3</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Describe Your Task</h3>
                    <p className="text-muted-foreground">
                      Tell us what you need help with so we can match you with the right Breezers.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary mr-3">
                    <span className="font-medium">4</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Your Breezers Arrive Ready to Help</h3>
                    <p className="text-muted-foreground">
                      Our supervised Breezers will arrive at the scheduled time, ready to tackle your task.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center p-4 bg-muted rounded-lg mb-6">
                <Clock className="h-6 w-6 text-primary mr-3" />
                <p className="text-sm">
                  <span className="font-medium">Booking Notice:</span> Please book at least 48 hours in advance to
                  ensure availability. For urgent requests, please call us directly.
                </p>
              </div>
            </div>

            <div className="flex justify-center">
              <div className="rounded-lg overflow-hidden shadow-md" style={{ maxWidth: "400px" }}>
                <Image
                  src="/breezer-home-relocation.jpeg"
                  alt="Breezer helping with home relocation"
                  width={400}
                  height={300}
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Tasks Our Breezers Can Help With</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Our Breezers are trained to assist with a wide variety of everyday tasks.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {tasks.map((task, index) => (
              <div key={index} className="flex items-start p-4 bg-background rounded-lg">
                <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                <span>{task}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Breezer Services</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Our Breezers can help with a wide range of tasks across different areas
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {breezerServices.map((service, index) => (
              <div
                key={index}
                className="bg-background p-6 rounded-lg shadow-sm border border-breezyee-teal/20 hover:border-breezyee-purple/30 transition-colors"
              >
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                  <service.icon className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-breezyee-purple">{service.title}</h3>
                <p className="text-muted-foreground">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Book Your Breezers</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Fill out the form below to book your Breezers. We'll confirm availability and provide you with all the
              details you need.
            </p>
          </div>

          <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-lg shadow-sm">
            <BreezerBookingForm />
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-6">Supporting Our Social Mission</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8">
            By hiring our Breezers, you're not just getting help with your tasks – you're supporting our mission to
            provide opportunities for young people who are not in education, employment, or training (NEET). Your
            booking helps these young people gain valuable work experience, build skills, and develop confidence.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" asChild>
              <Link href="/about">Learn More About Our Mission</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
