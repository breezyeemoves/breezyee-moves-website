import { Button } from "@/components/ui/button"
import {
  Home,
  Building,
  PackageOpen,
  Warehouse,
  CheckCircle2,
  Truck,
  MapPin,
  HelpingHand,
  GraduationCap,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import Script from "next/script"

export const metadata = {
  title: "Removal Services & Van Hire in London | BreeZyee Moves",
  description:
    "Professional removal services, man and van hire, and self-drive van hire in London. Home removals, office relocations, student accommodation, packing services, storage solutions, furniture removals",
  keywords:
    "removal services london, man and van london, van hire london, home removals, office relocations, student accommodation, packing services, storage solutions, furniture removals",
}

export default function ServicesPage() {
  const services = [
    {
      id: "home-removals",
      title: "Home Removals",
      description:
        "Our home removal service is designed to make your move as stress-free as possible. We handle everything from packing and loading to transportation and unpacking.",
      icon: Home,
      features: [
        "Careful handling of all belongings",
        "Efficient loading and unloading",
        "Furniture disassembly and reassembly",
        "Protection for floors and doorways",
        "Flexible scheduling options",
      ],
      image: "/home-removals-breezyee-mover.jpeg",
      bookingLink: "/services/book-removal",
      bookingText: "Book a Removal",
    },
    {
      id: "office-relocations",
      title: "Office Relocations",
      description: "Minimise downtime and disruption with our specialised office relocation services.",
      icon: Building,
      features: [
        "Weekend and after-hours moving options",
        "IT equipment handling and setup",
        "Furniture installation",
        "Minimal business disruption",
        "Project management throughout the move",
      ],
      image: "/office-relocations-team.jpeg",
      bookingLink: "/services/book-removal",
      bookingText: "Book Office Relocation",
    },
    {
      id: "student-accommodation",
      title: "Student Accommodation",
      description:
        "Moving to or from student accommodation? Our specialised student moving service offers affordable rates, flexible scheduling, and careful handling of your belongings.",
      icon: GraduationCap,
      features: [
        "Affordable rates for students",
        "Flexible scheduling around term times",
        "Storage options between terms",
        "Small or large moves handled efficiently",
        "Experienced with student accommodation requirements",
      ],
      image: "/student-accommodation-move.jpeg",
      bookingLink: "/services/book-removal",
      bookingText: "Book Student Move",
    },
    {
      id: "hire-a-breezer",
      title: "Hire a Breezer",
      description:
        "Need an extra pair of hands? Hire one of our young, energetic 'Breezers' for everyday tasks. From moving furniture to garden work, our Breezers are ready to help.",
      icon: HelpingHand,
      features: [
        "Hire up to 4 Breezers at once for bigger tasks",
        "Flexible hourly, half-day, or full-day rates",
        "Trained and supervised young employees",
        "Support our social mission helping NEET young people",
        "Available for a wide range of everyday tasks",
      ],
      image: "/breezer-home-relocation.jpeg",
      bookingLink: "/services/hire-a-breezer",
      bookingText: "Hire a Breezer",
    },
    {
      id: "packing",
      title: "Packing Services",
      description:
        "Let our experts handle the packing for you. We use high-quality materials and techniques to ensure your belongings are protected throughout the move.",
      icon: PackageOpen,
      features: [
        "Professional packing of all items",
        "Special care for fragile and valuable items",
        "High-quality packing materials",
        "Labeling and inventory management",
        "Unpacking and disposal of packing materials",
      ],
      image: "/packing-services-boxes.jpeg",
      bookingLink: "/services/book-removal",
      bookingText: "Book Packing Service",
    },
    {
      id: "van-hire",
      title: "Van Hire",
      description:
        "Need a van for your DIY move? We offer a range of vans for hire, from small vans for single items to large vans for full house moves. All our vehicles feature automatic transmission for easy driving.",
      icon: Truck,
      features: [
        "Various van sizes available (small, medium, large, and Luton)",
        "All vehicles have automatic transmission",
        "Flexible rental periods",
        "Competitive pricing",
        "Well-maintained, clean vehicles",
        "Optional moving equipment rental",
      ],
      image: "/luton-van-hire.jpeg",
      bookingLink: "/services/van-hire",
      bookingText: "Book a Van",
    },
    {
      id: "storage",
      title: "Storage Solutions",
      description:
        "Need somewhere to store your belongings? Our secure storage facilities are perfect for both short-term and long-term storage needs.",
      icon: Warehouse,
      features: [
        "Secure, climate-controlled facilities",
        "Flexible short and long-term options",
        "Easy access to your belongings",
        "Inventory management system",
        "Competitive pricing",
      ],
      image: "/storage-facility.jpeg",
      bookingLink: "/contact?service=storage",
      bookingText: "Enquire About Storage",
    },
  ]

  return (
    <div>
      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
              Our Removal Services in London & Surrounding Area's
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We offer a comprehensive range of removal services, man and van hire, and self-drive van hire options to
              meet all your moving needs in London and surrounding area's.
            </p>
            <div className="flex items-center justify-center mt-4 text-muted-foreground">
              <MapPin className="h-5 w-5 text-primary mr-2" />
              <span>Serving London and surrounding area's</span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="space-y-20">
            {services.map((service, index) => (
              <div
                key={index}
                id={service.id}
                className={`grid md:grid-cols-2 gap-8 items-center ${index % 2 === 1 ? "md:grid-flow-dense" : ""}`}
              >
                <div className={index % 2 === 1 ? "md:col-start-2" : ""}>
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                    <service.icon className="h-6 w-6" />
                  </div>
                  <h2 className="text-3xl font-bold mb-4">{service.title}</h2>
                  <p className="text-muted-foreground mb-6">{service.description}</p>

                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button asChild>
                      <Link href={service.bookingLink}>{service.bookingText}</Link>
                    </Button>
                    <Button variant="outline" asChild>
                      <a href="tel:02036330464">Call: 020 3633 0464</a>
                    </Button>
                  </div>
                </div>

                <div className={`${index % 2 === 1 ? "md:col-start-1" : ""} flex items-center justify-center`}>
                  {service.id === "home-removals" ? (
                    <div className="relative" style={{ maxWidth: "250px" }}>
                      <div className="rounded-lg overflow-hidden">
                        <Image
                          src={service.image || "/placeholder.svg"}
                          alt="BreeZyee mover carrying furniture during home removal"
                          width={250}
                          height={375}
                          className="w-full h-auto"
                          sizes="(max-width: 768px) 100vw, 250px"
                        />
                      </div>
                    </div>
                  ) : service.id === "student-accommodation" ? (
                    <div className="relative" style={{ maxWidth: "400px" }}>
                      <div className="rounded-lg overflow-hidden shadow-md">
                        <Image
                          src={service.image || "/placeholder.svg"}
                          alt="Student packing suitcase in accommodation"
                          width={600}
                          height={400}
                          className="w-full h-auto"
                          sizes="(max-width: 768px) 100vw, 400px"
                        />
                      </div>
                    </div>
                  ) : service.id === "office-relocations" ? (
                    <div className="relative" style={{ maxWidth: "250px" }}>
                      <div className="rounded-lg overflow-hidden">
                        <Image
                          src={service.image || "/placeholder.svg"}
                          alt={`BreeZyee team assisting with ${service.title.toLowerCase()}`}
                          width={250}
                          height={500}
                          className="w-full h-auto"
                          sizes="(max-width: 768px) 100vw, 250px"
                        />
                      </div>
                    </div>
                  ) : service.id === "packing" ? (
                    <div className="relative" style={{ maxWidth: "250px" }}>
                      <div className="rounded-lg overflow-hidden">
                        <Image
                          src={service.image || "/placeholder.svg"}
                          alt="Packed boxes ready for moving"
                          width={250}
                          height={188}
                          className="w-full h-auto"
                          sizes="(max-width: 768px) 100vw, 250px"
                        />
                      </div>
                    </div>
                  ) : service.id === "van-hire" ? (
                    <div className="relative" style={{ maxWidth: "350px" }}>
                      <div className="rounded-lg overflow-hidden shadow-md">
                        <Image
                          src={service.image || "/placeholder.svg"}
                          alt="Mercedes-Benz Luton van available for hire"
                          width={350}
                          height={234}
                          className="w-full h-auto"
                          sizes="(max-width: 768px) 100vw, 350px"
                        />
                      </div>
                    </div>
                  ) : service.id === "hire-a-breezer" ? (
                    <div className="relative" style={{ maxWidth: "400px" }}>
                      <div className="rounded-lg overflow-hidden">
                        <Image
                          src={service.image || "/placeholder.svg"}
                          alt={service.title}
                          width={400}
                          height={300}
                          className="w-full h-auto"
                          style={{ clipPath: "inset(15% 0 15% 0)" }}
                          sizes="(max-width: 768px) 100vw, 400px"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="relative h-64 md:h-[350px] w-full">
                      <Image
                        src={service.image || "/placeholder.svg"}
                        alt={service.title}
                        fill
                        className="object-cover rounded-lg"
                        sizes="(max-width: 768px) 100vw, 50vw"
                      />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="max-w-4xl mx-auto prose prose-lg">
            <h2 className="text-3xl font-bold text-center mb-8">Professional Removal Services in London</h2>

            <p>
              At BreeZyee Moves, we understand that every move is unique. Whether you're moving a small flat or a large
              family home, our professional removal services are tailored to meet your specific needs. Our experienced
              team handles every aspect of your move with care and efficiency, ensuring a smooth and stress-free
              experience.
            </p>

            <h3 className="text-2xl font-semibold mt-8 mb-4">Man and Van Services</h3>
            <p>
              Our man and van service is perfect for smaller moves or when you need to transport just a few items. This
              cost-effective solution provides you with a professional driver and helper who will assist with loading,
              transportation, and unloading. It's ideal for student moves, small flat relocations, or single item
              deliveries.
            </p>

            <h3 className="text-2xl font-semibold mt-8 mb-4">Self-Drive Van Hire</h3>
            <p>
              For those who prefer to handle their own move, our self-drive van hire service offers flexibility and
              convenience. Choose from our range of well-maintained vans, all featuring automatic transmission for easy
              driving. With competitive rates and various van sizes available, you can find the perfect vehicle for your
              DIY move.
            </p>

            <p className="mt-8">
              Whether you need full-service home removals, a man and van service, or self-drive van hire, BreeZyee Moves
              is your trusted partner for all your moving needs in London and surrounding areas. Contact us today for a
              free quote!
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-6">Find the Right Service for You</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8">
            Browse our comprehensive range of services above and select the one that best fits your needs.
          </p>
        </div>
      </section>

      {/* Service Schema Markup */}
      <Script
        id="removal-services-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Service",
            serviceType: "Removal Services",
            provider: {
              "@type": "LocalBusiness",
              name: "BreeZyee Moves",
              url: "https://www.breezyeemoves.co.uk",
            },
            areaServed: {
              "@type": "City",
              name: "London",
            },
            description: "Professional home and office removal services in London and surrounding areas.",
            offers: {
              "@type": "Offer",
              price: "0",
              priceCurrency: "GBP",
              availability: "https://schema.org/InStock",
            },
          }),
        }}
      />
    </div>
  )
}
