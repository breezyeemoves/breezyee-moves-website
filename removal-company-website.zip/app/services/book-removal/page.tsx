import { Home, CheckCircle2, CalendarRange } from "lucide-react"
import Image from "next/image"
import RemovalBookingForm from "@/components/removal-booking-form"

export const metadata = {
  title: "Book a Removal | BreeZyee Moves",
  description:
    "Book your home or office removal with BreeZyee Moves. Our professional team will ensure a smooth and stress-free moving experience.",
}

export default function BookRemovalPage() {
  const features = [
    "Professional and experienced moving team",
    "Careful handling of all your belongings",
    "Furniture disassembly and reassembly",
    "Protection for floors and doorways",
    "Flexible scheduling to suit your needs",
    "Comprehensive insurance coverage",
    "Packing and unpacking services available",
  ]

  return (
    <div>
      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Book a Removal Service</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Let our professional team take care of your move. We handle everything from packing and loading to
              transportation and unpacking.
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                <Home className="h-6 w-6" />
              </div>
              <h2 className="text-3xl font-bold mb-6">Our Removal Service</h2>
              <p className="text-muted-foreground mb-6">
                Our removal service is designed to make your move as stress-free as possible. Our experienced team will
                handle all aspects of your move with care and professionalism, ensuring your belongings arrive safely at
                your new home or office.
              </p>

              <ul className="space-y-2 mb-6">
                {features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="flex items-center p-4 bg-muted rounded-lg mb-6">
                <CalendarRange className="h-6 w-6 text-primary mr-3" />
                <p className="text-sm">
                  <span className="font-medium">Booking Notice:</span> Please book at least 3 days in advance to ensure
                  availability. For urgent moves, please call us directly.
                </p>
              </div>
            </div>

            <div className="relative h-64 md:h-auto">
              <Image src="/movers-furniture-house.png" alt="Removal Service" fill className="object-cover rounded-lg" />
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Book Your Move</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Fill out the form below to book your removal service. We'll contact you to confirm details and provide a
              quote.
            </p>
          </div>

          <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-lg shadow-sm">
            <RemovalBookingForm />
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Book Your Move?</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8">
            Fill out the form above to book your removal service. We'll contact you to confirm details and provide a
            quote.
          </p>
        </div>
      </section>
    </div>
  )
}
