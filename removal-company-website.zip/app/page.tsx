import Hero from "@/components/hero"
import Services from "@/components/services"
import Testimonials from "@/components/testimonials"
import Process from "@/components/process"
import Cta from "@/components/cta"
import FaqSection from "@/components/faq-section"
import Mission from "@/components/mission"
import Teamwork from "@/components/teamwork"
import LocationsServed from "@/components/locations-served"
import SeoContent from "@/components/seo-content"

export default function Home() {
  return (
    <div>
      <Hero />
      <Services />
      <Process />
      <Teamwork />
      <Mission />
      <Testimonials />
      <LocationsServed />
      <FaqSection />
      <SeoContent />
      <Cta />
    </div>
  )
}
