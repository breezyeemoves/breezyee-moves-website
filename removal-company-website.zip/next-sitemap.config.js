/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: process.env.NEXT_PUBLIC_APP_URL || "https://www.breezyeemoves.co.uk",
  generateRobotsTxt: false, // We're generating this in app/robots.ts
  exclude: ["/server-sitemap.xml", "/admin/*"],
  generateIndexSitemap: false,
  outDir: "public",
}
