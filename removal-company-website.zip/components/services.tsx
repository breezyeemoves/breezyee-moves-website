import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Home, Building, PackageOpen, Warehouse, Truck, HelpingHand, GraduationCap } from "lucide-react"
import Link from "next/link"

export default function Services() {
  const services = [
    {
      title: "Home Removals",
      description: "We handle your home move with care, ensuring all your belongings arrive safely at your new home.",
      icon: Home,
      link: "/services/book-removal",
    },
    {
      title: "Office Relocations",
      description: "Minimize downtime with our efficient office relocation services tailored to your business needs.",
      icon: Building,
      link: "/services/book-removal",
    },
    {
      title: "Student Accommodation",
      description: "Specialised moving services for students, with flexible scheduling and affordable rates.",
      icon: GraduationCap,
      link: "/services/book-removal",
    },
    {
      title: "Packing Services",
      description:
        "Our professional packing services ensure your items are protected during the entire moving process.",
      icon: PackageOpen,
      link: "/services/book-removal",
    },
    {
      title: "Van Hire",
      description: "Need a van for your DIY move? We offer a range of vans for hire to suit your needs.",
      icon: Truck,
      link: "/services/van-hire",
    },
    {
      title: "Hire a Breezer",
      description: "Need an extra pair of hands? Hire our young, energetic helpers for everyday tasks.",
      icon: HelpingHand,
      link: "/services/hire-a-breezer",
    },
    {
      title: "Storage Solutions",
      description: "Secure storage options for your belongings, whether you need short-term or long-term solutions.",
      icon: Warehouse,
      link: "/contact?service=storage",
    },
  ]

  return (
    <section className="py-16 md:py-24 bg-muted/50">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Our Services</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            We offer a comprehensive range of removal services and van hire options to meet all your moving needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-7 gap-6">
          {services.map((service, index) => (
            <Link href={service.link} key={index} className="group">
              <Card className="h-full transition-all duration-200 hover:shadow-md hover:border-breezyee-purple">
                <CardHeader>
                  <service.icon className="h-10 w-10 text-breezyee-teal mb-2" />
                  <CardTitle className="text-breezyee-purple group-hover:text-breezyee-teal transition-colors">
                    {service.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{service.description}</CardDescription>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
