import Link from "next/link"
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin, Globe, Clock } from "lucide-react"
import Image from "next/image"

export default function Footer() {
  return (
    <footer className="bg-muted">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Image src="/breezyee-logo.png" alt="BreeZyee Moves" width={40} height={40} />
              <h3 className="text-lg font-semibold text-breezyee-teal">BreeZyee Moves</h3>
            </div>
            <p className="text-muted-foreground mb-2">
              A Day's Move in a <span className="text-breezyee-purple font-medium">Breeze!</span>
            </p>
            <p className="text-muted-foreground mb-4">
              Professional and reliable removal services for homes and businesses in London & Surrounding Areas.
            </p>
            <div className="flex space-x-4">
              <Link
                href="https://facebook.com"
                className="text-muted-foreground hover:text-breezyee-teal"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </Link>
              <Link
                href="https://instagram.com"
                className="text-muted-foreground hover:text-breezyee-purple"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </Link>
              <Link
                href="https://twitter.com"
                className="text-muted-foreground hover:text-breezyee-teal"
                aria-label="Twitter"
              >
                <Twitter className="h-5 w-5" />
              </Link>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-2 text-breezyee-purple">Quick Links</h3>
            <ul className="grid grid-cols-2 sm:grid-cols-1 gap-2">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-breezyee-teal">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-muted-foreground hover:text-breezyee-teal">
                  Services
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-breezyee-teal">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/business-partnerships" className="text-muted-foreground hover:text-breezyee-teal">
                  Business Partnerships
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-breezyee-teal">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div className="sm:col-span-2 md:col-span-1">
            <h3 className="text-lg font-semibold mb-2 text-breezyee-purple">Services</h3>
            <ul className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-1 gap-2">
              <li>
                <Link href="/services/book-removal" className="text-muted-foreground hover:text-breezyee-teal">
                  Home Removals
                </Link>
              </li>
              <li>
                <Link href="/services/book-removal" className="text-muted-foreground hover:text-breezyee-teal">
                  Office Relocations
                </Link>
              </li>
              <li>
                <Link href="/services/book-removal" className="text-muted-foreground hover:text-breezyee-teal">
                  Student Accommodation
                </Link>
              </li>
              <li>
                <Link href="/services/book-removal" className="text-muted-foreground hover:text-breezyee-teal">
                  Packing Services
                </Link>
              </li>
              <li>
                <Link href="/services/van-hire" className="text-muted-foreground hover:text-breezyee-teal">
                  Van Hire
                </Link>
              </li>
              <li>
                <Link href="/services/hire-a-breezer" className="text-muted-foreground hover:text-breezyee-teal">
                  Hire a Breezer
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-2 text-breezyee-purple">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2">
                <MapPin className="h-5 w-5 text-breezyee-teal shrink-0 mt-0.5" />
                <span className="text-muted-foreground uppercase font-medium">LONDON & SURROUNDING AREA'S</span>
              </li>
              <li className="flex items-start space-x-2">
                <Phone className="h-5 w-5 text-breezyee-teal shrink-0 mt-0.5" />
                <div className="flex flex-col">
                  <Link href="tel:02036330464" className="text-muted-foreground hover:text-breezyee-teal">
                    020 3633 0464
                  </Link>
                  <Link href="tel:07398395022" className="text-muted-foreground hover:text-breezyee-teal">
                    07398 395 022
                  </Link>
                </div>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-breezyee-teal shrink-0" />
                <Link
                  href="mailto:contactus@breezyeemoves.co.uk"
                  className="text-muted-foreground hover:text-breezyee-teal break-all"
                >
                  contactus@breezyeemoves.co.uk
                </Link>
              </li>
              <li className="flex items-center space-x-2">
                <Globe className="h-5 w-5 text-breezyee-teal shrink-0" />
                <Link
                  href="https://www.breezyeemoves.co.uk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-breezyee-teal"
                >
                  www.breezyeemoves.co.uk
                </Link>
              </li>
              <li className="flex items-start space-x-2">
                <Clock className="h-5 w-5 text-breezyee-teal shrink-0 mt-0.5" />
                <div className="text-muted-foreground">
                  <div>24/7 Mon-Friday</div>
                  <div>Sat: 8am-8pm</div>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} BreeZyee Moves. All rights reserved.
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Link href="/privacy-policy" className="text-sm text-muted-foreground hover:text-breezyee-teal">
                Privacy Policy
              </Link>
              <Link href="/terms-of-service" className="text-sm text-muted-foreground hover:text-breezyee-teal">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
