"use client"

import { useState } from "react"
import { useForm, Controller } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, CalendarCheck } from "lucide-react"
import { submitRemovalBooking } from "@/app/actions"
import { addDays, format } from "date-fns"

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(6, { message: "Please enter a valid phone number." }),
  moveType: z.enum(["home-removals", "office-relocations", "packing", "storage", "other"], {
    required_error: "Please select a service type.",
  }),
  propertySize: z.enum(["studio", "1-bed", "2-bed", "3-bed", "4-bed", "5-bed", "office", "other"], {
    required_error: "Please select your property size.",
  }),
  moveDate: z.string().min(1, { message: "Please select a move date." }),
  moveTime: z.string().min(1, { message: "Please select a move time." }),
  fromAddress: z.string().min(5, { message: "Please enter your current address." }),
  toAddress: z.string().min(5, { message: "Please enter your destination address." }),
  additionalInfo: z.string().optional(),
})

type RemovalBookingFormValues = z.infer<typeof formSchema>

export default function RemovalBookingForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Calculate minimum date (3 days from now)
  const minDate = addDays(new Date(), 3)
  const formattedMinDate = format(minDate, "yyyy-MM-dd")

  const form = useForm<RemovalBookingFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      moveType: "home-removals",
      propertySize: "2-bed",
      moveDate: "",
      moveTime: "",
      fromAddress: "",
      toAddress: "",
      additionalInfo: "",
    },
  })

  // Generate time slots (8am to 6pm)
  const timeSlots = Array.from({ length: 11 }, (_, i) => {
    const hour = i + 8
    return `${hour}:00${hour < 12 ? " AM" : " PM"}`
  })

  async function onSubmit(values: RemovalBookingFormValues) {
    setIsSubmitting(true)
    setError(null)

    try {
      // Convert string date to Date object for the server action
      const moveDate = new Date(values.moveDate)

      await submitRemovalBooking({
        name: values.name,
        email: values.email,
        phone: values.phone,
        moveType: values.moveType,
        propertySize: values.propertySize,
        moveDate: moveDate,
        moveTime: values.moveTime,
        fromAddress: values.fromAddress,
        toAddress: values.toAddress,
        additionalInfo: values.additionalInfo || "",
      })
      setIsSuccess(true)
      form.reset()
    } catch (err) {
      console.error("Error submitting booking:", err)
      setError("There was a problem submitting your booking. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      {isSuccess ? (
        <div className="p-6 bg-green-50 border border-green-200 rounded-lg text-green-800">
          <div className="flex items-center mb-4">
            <CalendarCheck className="h-6 w-6 mr-2" />
            <h3 className="font-medium text-lg">Booking Request Received!</h3>
          </div>
          <p className="mb-4">
            Thank you for your removal booking request. We'll review your request and contact you shortly to confirm
            availability, provide a quote, and finalize details.
          </p>
          <Button className="mt-2" variant="outline" onClick={() => setIsSuccess(false)}>
            Make another booking
          </Button>
        </div>
      ) : (
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="Your email" type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="mt-4">
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="Your phone number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="pt-4 border-t">
                <h3 className="text-lg font-medium mb-4">Move Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Controller
                    name="moveType"
                    control={form.control}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Service Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a service" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="home-removals">Home Removals</SelectItem>
                            <SelectItem value="office-relocations">Office Relocations</SelectItem>
                            <SelectItem value="packing">Packing Services</SelectItem>
                            <SelectItem value="storage">Storage Solutions</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Controller
                    name="propertySize"
                    control={form.control}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Property Size</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select property size" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="studio">Studio</SelectItem>
                            <SelectItem value="1-bed">1 Bedroom</SelectItem>
                            <SelectItem value="2-bed">2 Bedrooms</SelectItem>
                            <SelectItem value="3-bed">3 Bedrooms</SelectItem>
                            <SelectItem value="4-bed">4 Bedrooms</SelectItem>
                            <SelectItem value="5-bed">5+ Bedrooms</SelectItem>
                            <SelectItem value="office">Office Space</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="pt-4 border-t">
                <h3 className="text-lg font-medium mb-4">Booking Date & Time</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Controller
                    name="moveDate"
                    control={form.control}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Move Date</FormLabel>
                        <FormControl>
                          <Input
                            type="date"
                            min={formattedMinDate}
                            value={field.value}
                            onChange={(e) => field.onChange(e.target.value)}
                          />
                        </FormControl>
                        <FormMessage />
                        <p className="text-xs text-muted-foreground mt-1">
                          * We operate Monday-Saturday. Minimum 3 days advance booking.
                        </p>
                      </FormItem>
                    )}
                  />

                  <Controller
                    name="moveTime"
                    control={form.control}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Move Time</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select time" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {timeSlots.map((time) => (
                              <SelectItem key={time} value={time}>
                                {time}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="pt-4 border-t">
                <h3 className="text-lg font-medium mb-4">Addresses</h3>
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="fromAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Current Address</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Your current address" className="min-h-20" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="toAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Destination Address</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Where you're moving to" className="min-h-20" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="pt-4 border-t">
                <FormField
                  control={form.control}
                  name="additionalInfo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Information</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Any special requirements or information about your move"
                          className="min-h-24"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {error && (
              <div className="p-3 text-red-600 bg-red-50 border border-red-200 rounded-md text-sm">{error}</div>
            )}

            <Button type="submit" disabled={isSubmitting} className="w-full md:w-auto">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSubmitting ? "Submitting..." : "Book Removal Service"}
            </Button>
          </form>
        </Form>
      )}
    </div>
  )
}
