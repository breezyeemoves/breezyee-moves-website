import Image from "next/image"

export default function Teamwork() {
  return (
    <section className="py-12 md:py-16 bg-muted/30">
      <div className="container">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">Team Work Makes The Dream Work</h2>
            <p className="text-lg text-breezyee-purple font-medium mb-6">
              At BreeZyee Moves, we believe in the power of collaboration. Our dedicated team works together seamlessly
              to ensure your move is handled with care, efficiency, and professionalism.
            </p>
            <p className="text-lg text-muted-foreground">
              Each team member brings unique skills and experiences, but they all share the same commitment to
              excellence and customer satisfaction. When you choose BreeZyee Moves, you're not just hiring movers –
              you're partnering with a team that's passionate about making your move as smooth as possible.
            </p>
          </div>
          <div className="relative h-80 md:h-[500px] rounded-lg overflow-hidden shadow-lg border-4 border-breezyee-teal/20">
            <Image
              src="/team-working-van.jpeg"
              alt="BreeZyee Moves team working together at a moving van"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
