"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, CalendarCheck } from "lucide-react"
import { addDays, format } from "date-fns"
import VanSizeSelector from "./van-size-selector"

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(6, { message: "Please enter a valid phone number." }),
  vanSize: z.string().min(1, { message: "Please select a van size." }),
  pickupDate: z.string().min(1, { message: "Please select a pickup date." }),
  pickupTime: z.string().min(1, { message: "Please select a pickup time." }),
  duration: z.enum(["half-day", "full-day", "multiple-days"], {
    required_error: "Please select a rental duration.",
  }),
  additionalInfo: z.string().optional(),
})

type VanBookingFormValues = z.infer<typeof formSchema>

export default function VanBookingForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  // Calculate minimum date (tomorrow)
  const minDate = addDays(new Date(), 1)
  const formattedMinDate = format(minDate, "yyyy-MM-dd")

  const form = useForm<VanBookingFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      vanSize: "medium",
      pickupDate: "",
      pickupTime: "",
      duration: "full-day",
      additionalInfo: "",
    },
  })

  // Generate time slots (8am to 6pm)
  const timeSlots = Array.from({ length: 11 }, (_, i) => {
    const hour = i + 8
    return `${hour}:00${hour < 12 ? " AM" : " PM"}`
  })

  async function onSubmit(values: VanBookingFormValues) {
    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      console.log(values)
      setIsSuccess(true)
      form.reset()
    } catch (err) {
      console.error("Error submitting form:", err)
    } finally {
      setIsSubmitting(false)
    }
  }

  // Reset success state
  const handleReset = () => {
    setIsSuccess(false)
  }

  return (
    <div className="space-y-6">
      {isSuccess ? (
        <div className="p-6 bg-green-50 border border-green-200 rounded-lg text-green-800">
          <div className="flex items-center mb-4">
            <CalendarCheck className="h-6 w-6 mr-2" />
            <h3 className="font-medium text-lg">Booking Request Received!</h3>
          </div>
          <p className="mb-4">
            Thank you for your van hire booking request. We'll review your request and contact you shortly to confirm
            availability and finalize details.
          </p>
          <Button className="mt-2" variant="outline" onClick={handleReset}>
            Make another booking
          </Button>
        </div>
      ) : (
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="Your email" type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="mt-4">
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="Your phone number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="pt-4 border-t">
                <FormField
                  control={form.control}
                  name="vanSize"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <VanSizeSelector selectedSize={field.value} onChange={field.onChange} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="pt-4 border-t">
                <h3 className="text-lg font-medium mb-4">Booking Details</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="pickupDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pickup Date</FormLabel>
                          <FormControl>
                            <Input type="date" min={formattedMinDate} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="pickupTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pickup Time</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select time" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {timeSlots.map((time) => (
                                <SelectItem key={time} value={time}>
                                  {time}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="duration"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rental Duration</FormLabel>
                        <div className="grid grid-cols-1 gap-2">
                          <div className="flex items-center space-x-2">
                            <input
                              type="radio"
                              id="half-day"
                              value="half-day"
                              checked={field.value === "half-day"}
                              onChange={() => field.onChange("half-day")}
                              className="h-4 w-4 text-primary"
                            />
                            <label htmlFor="half-day">Half Day (4 hours)</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input
                              type="radio"
                              id="full-day"
                              value="full-day"
                              checked={field.value === "full-day"}
                              onChange={() => field.onChange("full-day")}
                              className="h-4 w-4 text-primary"
                            />
                            <label htmlFor="full-day">Full Day (8 hours)</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input
                              type="radio"
                              id="multiple-days"
                              value="multiple-days"
                              checked={field.value === "multiple-days"}
                              onChange={() => field.onChange("multiple-days")}
                              className="h-4 w-4 text-primary"
                            />
                            <label htmlFor="multiple-days">Multiple Days (Contact for details)</label>
                          </div>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="additionalInfo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Additional Information</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Any special requirements or information about your van hire needs"
                            className="min-h-24"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </div>

            <Button type="submit" disabled={isSubmitting} className="w-full md:w-auto">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSubmitting ? "Submitting..." : "Book Van"}
            </Button>
          </form>
        </Form>
      )}
    </div>
  )
}
