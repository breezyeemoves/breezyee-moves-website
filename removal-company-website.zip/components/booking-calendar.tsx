"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { CalendarIcon } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface BookingCalendarProps {
  onDateSelect: (date: Date | undefined) => void
  onTimeSelect: (time: string) => void
  selectedDate: Date | undefined
  selectedTime: string
  minDate?: Date
  className?: string
}

export default function BookingCalendar({
  onDateSelect,
  onTimeSelect,
  selectedDate,
  selectedTime,
  minDate = new Date(),
  className,
}: BookingCalendarProps) {
  const [calendarOpen, setCalendarOpen] = useState(false)

  // Generate available time slots (8am to 6pm, hourly)
  const timeSlots = Array.from({ length: 11 }, (_, i) => {
    const hour = i + 8
    return `${hour}:00${hour < 12 ? " AM" : " PM"}`
  })

  return (
    <div className={cn("space-y-4", className)}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Select Date</label>
          <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !selectedDate && "text-muted-foreground")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {selectedDate ? format(selectedDate, "PPP") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => {
                  onDateSelect(date)
                  setCalendarOpen(false)
                }}
                disabled={(date) => date < minDate || date.getDay() === 0} // Disable past dates and Sundays
                initialFocus
                footer={
                  <div className="px-4 py-2 border-t text-xs text-muted-foreground">* We operate Monday-Saturday</div>
                }
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Select Time</label>
          <Select
            value={selectedTime}
            onValueChange={(value) => {
              // Safe check to ensure onTimeSelect is a function
              if (typeof onTimeSelect === "function") {
                onTimeSelect(value)
              } else {
                console.warn("onTimeSelect is not a function")
              }
            }}
            disabled={!selectedDate}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select time" />
            </SelectTrigger>
            <SelectContent>
              {timeSlots.map((time) => (
                <SelectItem key={time} value={time}>
                  {time}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  )
}
