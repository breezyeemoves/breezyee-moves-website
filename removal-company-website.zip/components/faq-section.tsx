import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function FaqSection() {
  const faqs = [
    {
      question: "How far in advance should I book my move?",
      answer:
        "We recommend booking at least 4-6 weeks in advance, especially during peak moving seasons (spring and summer). However, we can sometimes accommodate last-minute moves depending on availability.",
    },
    {
      question: "Do you provide packing materials?",
      answer:
        "Yes, we provide a full range of packing materials including boxes, bubble wrap, packing paper, tape, and specialised containers for delicate items.",
    },
    {
      question: "How do you handle fragile or valuable items?",
      answer: "We take extra care with fragile and valuable items, using specialised packing materials and techniques.",
    },
    {
      question: "Do you offer storage solutions?",
      answer:
        "Yes, we offer both short-term and long-term storage solutions in our secure, climate-controlled facilities.",
    },
    {
      question: "What is your cancellation policy?",
      answer:
        "We understand that plans can change. Cancellations made more than 7 days before your scheduled move are fully refundable. For cancellations within 7 days, a small fee may apply. Please contact us as soon as possible if you need to cancel or reschedule.",
    },
  ]

  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Frequently Asked Questions</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Find answers to common questions about our moving services.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-breezyee-teal/20">
                <AccordionTrigger className="text-left text-breezyee-purple hover:text-breezyee-teal">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent>{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
