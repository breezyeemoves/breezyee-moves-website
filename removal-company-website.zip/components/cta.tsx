import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Cta() {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-r from-breezyee-teal to-breezyee-purple text-white">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-white">Ready to Make Your Move?</h2>
          <p className="text-lg mb-8 text-white/90">
            Contact us today for a free, no-obligation quote and let us take the stress out of your move.
          </p>
          <div className="flex justify-center">
            <Button
              size="lg"
              variant="secondary"
              asChild
              className="text-lg bg-white text-breezyee-purple hover:bg-white/90 hover:text-breezyee-teal px-8 py-6 shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              <Link href="/contact">Get a Free Quote</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
