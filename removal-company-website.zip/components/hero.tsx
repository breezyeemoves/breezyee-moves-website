"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Hero() {
  const [activeTab, setActiveTab] = useState("removals")

  return (
    <section className="relative">
      {/* Video Background with improved clarity and teal overlay */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        {/* Transparent teal overlay */}
        <div className="absolute inset-0 bg-breezyee-teal/30 z-10"></div>
        <video
          autoPlay
          muted
          loop
          playsInline
          className="w-full h-full object-cover brightness-90" // Increased brightness for better clarity
          poster="/moving-truck-houses.png"
          preload="auto"
          aria-hidden="true"
        >
          <source src="/breezyee-intro-video.mp4" type="video/mp4" />
        </video>
      </div>

      {/* Hero Content - moved further down with increased padding */}
      <div className="container relative z-10 pt-16 pb-12 md:pt-40 md:pb-32 lg:pt-48 lg:pb-40">
        <div className="max-w-2xl text-white">
          {/* Logo as main title */}
          <div className="flex flex-col items-center md:items-start mb-8 md:mb-10">
            <Image
              src="/breezyee-logo.png"
              alt="BreeZyee Moves - Professional Removal Services in London"
              width={200}
              height={200}
              className="w-40 md:w-56 mb-6 md:mb-8"
              priority
            />
            <h1 className="text-2xl md:text-4xl font-bold mb-3 text-center md:text-left">
              A Day's Move in a <span className="text-secondary">Breeze!</span>
            </h1>
            <p className="text-lg md:text-xl italic">A move for you is a leap for the next generation</p>
          </div>

          {/* Service Selection Tabs - Improved design */}
          <div className="mb-6 md:mb-8">
            <h2 className="text-xl md:text-2xl font-bold mb-4 text-white">Choose Your Service:</h2>
            <Tabs defaultValue="removals" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6 md:mb-8 bg-white/20 p-1 h-auto">
                <TabsTrigger
                  value="removals"
                  className="text-base md:text-lg font-semibold py-3 data-[state=active]:bg-breezyee-purple data-[state=active]:text-white"
                >
                  Removal Services
                </TabsTrigger>
                <TabsTrigger
                  value="van-hire"
                  className="text-base md:text-lg font-semibold py-3 data-[state=active]:bg-breezyee-teal data-[state=active]:text-white"
                >
                  Van Hire
                </TabsTrigger>
              </TabsList>
              <TabsContent value="removals" className="mt-0">
                <p className="text-base md:text-xl mb-6 md:mb-8">
                  We make your move stress-free with our professional, reliable, and efficient removal services for
                  homes and businesses.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
                  <Button size="lg" asChild className="text-base bg-breezyee-purple hover:bg-breezyee-purple/90">
                    <Link href="/services/book-removal">Book Removal Service</Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="secondary"
                    asChild
                    className="text-base bg-white text-breezyee-purple hover:bg-white/90"
                  >
                    <Link href="/contact?service=removals">Get a Free Quote</Link>
                  </Button>
                </div>
              </TabsContent>
              <TabsContent value="van-hire" className="mt-0">
                <p className="text-base md:text-xl mb-6 md:mb-8">
                  Need a van for your DIY move? We offer flexible and affordable van hire options with various sizes to
                  suit your needs.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
                  <Button size="lg" asChild className="text-base bg-breezyee-teal hover:bg-breezyee-teal/90">
                    <Link href="/services/van-hire">Book a Van</Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="secondary"
                    asChild
                    className="text-base bg-white text-breezyee-teal hover:bg-white/90"
                  >
                    <Link href="/contact?service=van-hire">Get a Quote</Link>
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </section>
  )
}
