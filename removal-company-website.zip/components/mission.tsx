import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export default function Mission() {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-r from-breezyee-purple/20 to-breezyee-teal/20">
      <div className="container">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-6">Our Mission</h2>
            <p className="text-xl mb-6 text-breezyee-purple">
              At BreeZyee Moves, we bridge gaps for young people (NEET), empowering them to overcome challenges and
              build brighter futures.
            </p>
            <p className="text-lg mb-8 text-muted-foreground">
              A move for you is a leap for the next generation. By choosing our services, you're helping us create
              opportunities for young people in our community.
            </p>
            <Button asChild className="bg-breezyee-purple hover:bg-breezyee-teal">
              <Link href="/about">Learn More About Our Impact</Link>
            </Button>
          </div>
          <div className="order-1 md:order-2 flex justify-center">
            <div className="rounded-lg overflow-hidden shadow-lg">
              <div className="relative" style={{ width: "300px", height: "400px", overflow: "hidden" }}>
                <Image
                  src="/breezyee-team-loading.jpeg"
                  alt="BreeZyee team members loading a moving van"
                  fill
                  className="object-cover object-center"
                  style={{ objectPosition: "center 40%" }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
