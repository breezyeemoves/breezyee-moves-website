"use client"

import { useState } from "react"
import { useForm, Controller } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, CalendarCheck, Users } from "lucide-react"
import { addDays, format } from "date-fns"

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(6, { message: "Please enter a valid phone number." }),
  breezerCount: z.string().min(1, { message: "Please select the number of Breezers." }),
  taskDate: z.string().min(1, { message: "Please select a date for the task." }),
  taskTime: z.string().min(1, { message: "Please select a time for the task." }),
  taskDuration: z.enum(["2-hours", "4-hours", "6-hours", "8-hours"], {
    required_error: "Please select the task duration.",
  }),
  taskDescription: z.string().min(10, { message: "Please describe the task in more detail." }),
  taskLocation: z.string().min(5, { message: "Please provide the task location." }),
  additionalInfo: z.string().optional(),
})

type BreezerBookingFormValues = z.infer<typeof formSchema>

export default function BreezerBookingForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Calculate minimum date (2 days from now)
  const minDate = addDays(new Date(), 2)
  const formattedMinDate = format(minDate, "yyyy-MM-dd")

  const form = useForm<BreezerBookingFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      breezerCount: "1",
      taskDate: "",
      taskTime: "",
      taskDuration: "4-hours",
      taskDescription: "",
      taskLocation: "",
      additionalInfo: "",
    },
  })

  async function onSubmit(values: BreezerBookingFormValues) {
    setIsSubmitting(true)
    setError(null)

    try {
      // In a real implementation, this would send data to your backend
      // or directly to contactus@breezyeemoves.co.uk
      await new Promise((resolve) => setTimeout(resolve, 1000))

      console.log(values)
      setIsSuccess(true)
      form.reset()
    } catch (err) {
      setError("There was a problem submitting your booking. Please try again.")
      console.error(err)
    } finally {
      setIsSubmitting(false)
    }
  }

  // Generate options for Breezer count (1-20)
  const breezerOptions = Array.from({ length: 20 }, (_, i) => ({
    value: String(i + 1),
    label: String(i + 1),
  }))

  // Generate time slots (8am to 6pm)
  const timeSlots = Array.from({ length: 11 }, (_, i) => {
    const hour = i + 8
    return `${hour}:00${hour < 12 ? " AM" : " PM"}`
  })

  return (
    <div className="space-y-6">
      {isSuccess ? (
        <div className="p-6 bg-green-50 border border-green-200 rounded-lg text-green-800">
          <div className="flex items-center mb-4">
            <CalendarCheck className="h-6 w-6 mr-2" />
            <h3 className="font-medium text-lg">Booking Request Received!</h3>
          </div>
          <p className="mb-4">
            Thank you for your Breezer booking request. We'll review your request and contact you shortly to confirm
            availability and finalize details.
          </p>
          <Button className="mt-2" variant="outline" onClick={() => setIsSuccess(false)}>
            Make another booking
          </Button>
        </div>
      ) : (
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="Your email" type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="mt-4">
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="Your phone number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="pt-4 border-t">
                <h3 className="text-lg font-medium mb-4">Booking Details</h3>

                <Controller
                  name="breezerCount"
                  control={form.control}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Number of Breezers</FormLabel>
                      <div className="flex items-center gap-2">
                        <Users className="h-5 w-5 text-primary" />
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select number of Breezers" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {breezerOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="text-sm text-muted-foreground mt-2">
                        Select from 1 to 20 Breezers depending on the size and complexity of your task.
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="mt-6">
                  <Controller
                    name="taskDuration"
                    control={form.control}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Task Duration</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select duration" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="2-hours">2 Hours</SelectItem>
                            <SelectItem value="4-hours">4 Hours (Half Day)</SelectItem>
                            <SelectItem value="6-hours">6 Hours</SelectItem>
                            <SelectItem value="8-hours">8 Hours (Full Day)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="pt-4 border-t">
                <h3 className="text-lg font-medium mb-4">Date & Time</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Controller
                    name="taskDate"
                    control={form.control}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Task Date</FormLabel>
                        <FormControl>
                          <Input
                            type="date"
                            min={formattedMinDate}
                            value={field.value}
                            onChange={(e) => field.onChange(e.target.value)}
                          />
                        </FormControl>
                        <FormMessage />
                        <p className="text-xs text-muted-foreground mt-1">
                          * We operate Monday-Saturday. Minimum 2 days advance booking.
                        </p>
                      </FormItem>
                    )}
                  />

                  <Controller
                    name="taskTime"
                    control={form.control}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Task Time</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select time" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {timeSlots.map((time) => (
                              <SelectItem key={time} value={time}>
                                {time}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="pt-4 border-t">
                <FormField
                  control={form.control}
                  name="taskLocation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Task Location</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Please provide the address where the Breezers will be working"
                          className="min-h-20"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="pt-4 border-t">
                <FormField
                  control={form.control}
                  name="taskDescription"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Task Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Please describe the task you need help with in detail"
                          className="min-h-24"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="pt-4 border-t">
                <FormField
                  control={form.control}
                  name="additionalInfo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Information</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Any special requirements or information about your task"
                          className="min-h-24"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {error && (
              <div className="p-3 text-red-600 bg-red-50 border border-red-200 rounded-md text-sm">{error}</div>
            )}

            <Button type="submit" disabled={isSubmitting} className="w-full md:w-auto">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSubmitting ? "Submitting..." : "Book Breezers"}
            </Button>
          </form>
        </Form>
      )}
    </div>
  )
}
