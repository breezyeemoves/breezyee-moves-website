export default function SeoContent() {
  return (
    <section className="py-12 md:py-16 bg-white">
      <div className="container">
        <div className="max-w-4xl mx-auto prose prose-lg">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-6 text-center text-breezyee-teal">
            Professional Removal Services in London
          </h2>

          <p>
            BreeZyee Moves is a trusted removal company in London offering comprehensive moving services for homes and
            businesses. Whether you need a full-service home removal, a man and van service for smaller moves, or
            self-drive van hire for DIY moving, our team is here to make your move as smooth and stress-free as
            possible.
          </p>

          <h3 className="text-2xl font-semibold mt-8 mb-4 text-breezyee-purple">Expert Home Removals in London</h3>
          <p>
            Moving home can be one of life's most stressful experiences, but with BreeZyee Moves, it doesn't have to be.
            Our professional home removal service covers everything from careful packing of your belongings to safe
            transportation and unpacking at your new home. We handle furniture disassembly and reassembly, and provide
            special care for fragile items. Our experienced movers are trained to handle all aspects of your move with
            care and efficiency.
          </p>

          <h3 className="text-2xl font-semibold mt-8 mb-4 text-breezyee-purple">Reliable Man and Van Service</h3>
          <p>
            For smaller moves or single item deliveries, our man and van service offers the perfect solution. Our
            friendly, professional team will help load, transport, and unload your items, saving you time and effort.
            This service is ideal for student moves, flat shares, or when you just need to move a few items. With
            BreeZyee Moves, you get the same level of professionalism and care as our full removal service, but scaled
            to meet your specific needs.
          </p>

          <h3 className="text-2xl font-semibold mt-8 mb-4 text-breezyee-purple">Flexible Self-Drive Van Hire</h3>
          <p>
            If you prefer to handle the move yourself, our self-drive van hire service gives you the freedom to move at
            your own pace. We offer a range of van sizes to suit different needs, from small vans for single items to
            large Luton vans for full house moves. All our vehicles feature automatic transmission for easy driving and
            are well-maintained for reliability. With flexible rental periods and competitive pricing, our van hire
            service is a cost-effective solution for DIY movers.
          </p>

          <h3 className="text-2xl font-semibold mt-8 mb-4 text-breezyee-purple">Why Choose BreeZyee Moves?</h3>
          <p>
            At BreeZyee Moves, we combine professional service with a social mission. Not only do we provide exceptional
            moving services, but we also create opportunities for young people not in education, employment, or training
            (NEET). When you choose us, you're not just getting a reliable removal service – you're helping us make a
            positive impact in our community.
          </p>

          <p className="mt-8">
            Contact BreeZyee Moves today for a free, no-obligation quote for your home removal, man and van service, or
            self-drive van hire needs in London and surrounding area's.
          </p>
        </div>
      </div>
    </section>
  )
}
