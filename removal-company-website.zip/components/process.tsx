import { CheckCircle2, Truck, ClipboardList, Home } from "lucide-react"

export default function Process() {
  const steps = [
    {
      title: "Request a Quote",
      description: "Fill in our simple form or call us to get a free, no-obligation quote for your move.",
      icon: ClipboardList,
    },
    {
      title: "Plan Your Move",
      description: "Our team will work with you to plan every detail of your move, from packing to transportation.",
      icon: CheckCircle2,
    },
    {
      title: "Moving Day",
      description: "Our professional movers will handle everything on the day, ensuring a smooth and efficient move.",
      icon: Truck,
    },
    {
      title: "Settle In",
      description: "We'll help you unpack and set up your new space, so you can start enjoying it right away.",
      icon: Home,
    },
  ]

  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">How It Works</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Our simple process makes moving easy and stress-free.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <div className="relative mb-4">
                <div className="flex items-center justify-center w-16 h-16 rounded-full bg-breezyee-teal/10 text-breezyee-teal">
                  <step.icon className="h-8 w-8" />
                </div>
                {index < steps.length - 1 && (
                  <div
                    className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-breezyee-teal to-breezyee-purple -translate-y-1/2"
                    style={{ width: "calc(100% - 4rem)" }}
                  ></div>
                )}
              </div>
              <h3 className="text-xl font-semibold mb-2 text-breezyee-purple">
                Step {index + 1}: {step.title}
              </h3>
              <p className="text-muted-foreground">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
