import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Star } from "lucide-react"
import Image from "next/image"

export default function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Homeowner",
      content:
        "BreeZyee Moves made our house move so much easier than expected. The team was professional, careful with our belongings, and incredibly efficient. I would definitely use their services again!",
      rating: 5,
      image: "/professional-woman-headshot.png",
    },
    {
      name: "David Thompson",
      role: "Business Owner",
      content:
        "We needed to relocate our office with minimal disruption to our business. BreeZyee Moves delivered exactly what they promised - a smooth, quick move with excellent service from start to finish.",
      rating: 5,
      image: "/professional-man-headshot.png",
    },
    {
      name: "Emma Wilson",
      role: "Apartment Renter",
      content:
        "As a first-time mover, I was nervous about the whole process. The team at BreeZyee Moves was patient, helpful, and made everything so simple. Their packing service was particularly impressive!",
      rating: 4,
      image: "/young-woman-headshot.png",
    },
  ]

  return (
    <section className="py-16 md:py-24 bg-muted/50">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">What Our Customers Say</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Don't just take our word for it - hear from some of our satisfied customers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="h-full border-breezyee-teal/20 hover:border-breezyee-teal transition-colors">
              <CardContent className="pt-6">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <p className="mb-6 italic">"{testimonial.content}"</p>
              </CardContent>
              <CardFooter>
                <div className="flex items-center">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden mr-4">
                    <Image
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold text-breezyee-purple">{testimonial.name}</h4>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
