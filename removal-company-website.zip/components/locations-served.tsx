import { MapPin } from "lucide-react"

export default function LocationsServed() {
  const locations = [
    "Central London",
    "North London",
    "East London",
    "South London",
    "West London",
    "Greater London",
    "Islington",
    "Camden",
    "Hackney",
    "Westminster",
    "Kensington",
    "Chelsea",
    "Hammersmith",
    "Fulham",
  ]

  return (
    <section className="py-12 md:py-16 bg-muted/30">
      <div className="container">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Areas We Serve</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            BreeZyee Moves provides removal services, man and van hire, and self-drive van hire throughout London and
            surrounding area's.
          </p>
        </div>

        <div className="flex items-center justify-center mb-8">
          <MapPin className="h-6 w-6 text-breezyee-purple mr-2" />
          <span className="text-xl font-medium text-breezyee-teal uppercase">LONDON & SURROUNDING AREA'S</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 text-center">
          {locations.map((location, index) => (
            <div
              key={index}
              className="p-4 bg-background rounded-md shadow-sm border border-breezyee-teal/10 hover:border-breezyee-purple/30 transition-colors"
            >
              <span className="text-base font-medium">{location}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
