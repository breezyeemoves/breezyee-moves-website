import { format, addDays, isBefore, isEqual } from "date-fns"

export const formatDate = (date: Date | string): string => {
  const dateObj = typeof date === "string" ? new Date(date) : date
  return format(dateObj, "PPP")
}

export const formatTime = (time: string): string => {
  return time
}

export const getMinBookingDate = (daysAhead = 1): Date => {
  return addDays(new Date(), daysAhead)
}

export const getFormattedMinDate = (daysAhead = 1): string => {
  return format(getMinBookingDate(daysAhead), "yyyy-MM-dd")
}

export const isDateAvailable = (date: Date, unavailableDates: Date[] = []): boolean => {
  // Check if date is a Sunday (0 is Sunday in JavaScript)
  if (date.getDay() === 0) return false

  // Check if date is in the past
  if (isBefore(date, new Date())) return false

  // Check if date is in the unavailable dates
  return !unavailableDates.some((unavailableDate) =>
    isEqual(new Date(unavailableDate.setHours(0, 0, 0, 0)), new Date(date.setHours(0, 0, 0, 0))),
  )
}

export const generateTimeSlots = (startHour = 8, endHour = 18): string[] => {
  return Array.from({ length: endHour - startHour + 1 }, (_, i) => {
    const hour = i + startHour
    return `${hour}:00${hour < 12 ? " AM" : " PM"}`
  })
}
