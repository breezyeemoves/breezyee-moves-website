import { z } from "zod"

export const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(6, { message: "Please enter a valid phone number." }),
  moveType: z.string({ required_error: "Please select a service type." }),
  message: z.string().min(10, { message: "Message must be at least 10 characters." }),
})

export const removalBookingSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(6, { message: "Please enter a valid phone number." }),
  moveType: z.enum(["home-removals", "office-relocations", "packing", "storage", "other"], {
    required_error: "Please select a service type.",
  }),
  propertySize: z.enum(["studio", "1-bed", "2-bed", "3-bed", "4-bed", "5-bed", "office", "other"], {
    required_error: "Please select your property size.",
  }),
  moveDate: z.string().min(1, { message: "Please select a move date." }),
  moveTime: z.string().min(1, { message: "Please select a move time." }),
  fromAddress: z.string().min(5, { message: "Please enter your current address." }),
  toAddress: z.string().min(5, { message: "Please enter your destination address." }),
  additionalInfo: z.string().optional(),
})

export const vanBookingSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(6, { message: "Please enter a valid phone number." }),
  vanSize: z.string().min(1, { message: "Please select a van size." }),
  pickupDate: z.string().min(1, { message: "Please select a pickup date." }),
  pickupTime: z.string().min(1, { message: "Please select a pickup time." }),
  duration: z.enum(["half-day", "full-day", "multiple-days"], {
    required_error: "Please select a rental duration.",
  }),
  additionalInfo: z.string().optional(),
})

export const breezerBookingSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(6, { message: "Please enter a valid phone number." }),
  breezerCount: z.string().min(1, { message: "Please select the number of Breezers." }),
  taskDate: z.string().min(1, { message: "Please select a date for the task." }),
  taskTime: z.string().min(1, { message: "Please select a time for the task." }),
  taskDuration: z.enum(["2-hours", "4-hours", "6-hours", "8-hours"], {
    required_error: "Please select the task duration.",
  }),
  taskDescription: z.string().min(10, { message: "Please describe the task in more detail." }),
  taskLocation: z.string().min(5, { message: "Please provide the task location." }),
  additionalInfo: z.string().optional(),
})

export const businessPartnershipSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  companyName: z.string().min(2, { message: "Company name must be at least 2 characters." }),
  position: z.string().min(2, { message: "Position must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(6, { message: "Please enter a valid phone number." }),
  businessType: z.enum(["estate-agent", "property-manager", "corporate", "other"], {
    required_error: "Please select a business type.",
  }),
  message: z.string().min(10, { message: "Message must be at least 10 characters." }),
})
