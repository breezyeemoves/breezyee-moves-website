/**
 * Environment variable utility to ensure required environment variables are available
 */

export const getEnv = (key: string, defaultValue?: string): string => {
  const value = process.env[key] || defaultValue

  if (!value) {
    throw new Error(`Environment variable ${key} is not set`)
  }

  return value
}

export const env = {
  // App
  NODE_ENV: getEnv("NODE_ENV", "development"),
  APP_URL: getEnv("NEXT_PUBLIC_APP_URL", "http://localhost:3000"),

  // Email
  RESEND_API_KEY: getEnv("RESEND_API_KEY", ""),

  // Database
  DATABASE_URL: getEnv("DATABASE_URL", ""),
  SUPABASE_URL: getEnv("NEXT_PUBLIC_SUPABASE_URL", ""),
  SUPABASE_ANON_KEY: getEnv("NEXT_PUBLIC_SUPABASE_ANON_KEY", ""),
}
